import React from 'react'
import Restuarant  from './component/Basics/Restuarant';


const App = () => {
  return (
    <>
      
      <Restuarant />
      
    </>
  )
};





export default App